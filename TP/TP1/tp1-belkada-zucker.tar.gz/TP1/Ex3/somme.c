#include<stdio.h>
#include<string.h>
#include<mpi.h>
#include<unistd.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define SIZE_H_N 50


int main(int argc,char argv[])
{
	int	my_rank;
	int	p;	//nombredeprocessus/
	int	source;	//rangdel’emetteur/
	int	dest;	//rangdurecepteur	/
	int	tag=0;	//	etiquettedu	message	/
	char message[100];
	int nombre_recu;
	int nombre_alea;
	MPI_Status	status;
	char hostname[SIZE_H_N];
	int max_size;
	gethostname(hostname,SIZE_H_N);

//	Initialisation	/
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
	MPI_Comm_size(MPI_COMM_WORLD,&p);
	if ((p>>1)&1 != 1)
	{
		exit(0);
	}
	srand(time(NULL) +my_rank*p);   // Initialization, should only be called once.
	int r = rand(); 
	
	nombre_alea = (r%p)+1;
	printf("Mon rang est le #%d et mon nombre %d\n", my_rank, nombre_alea);
	int i = 1;
	if ((my_rank>>i)&1 == 1 && my_rank != 0)
		{
			printf("coucou 1\n");
			if (my_rank < p-1)
			{
				MPI_Recv(&nombre_recu,1,MPI_INT,my_rank+1,tag,MPI_COMM_WORLD,&status);
				nombre_alea += nombre_recu;
			}	
			
			MPI_Send(&nombre_alea,1,MPI_INT,my_rank-1,tag,MPI_COMM_WORLD);
		}else if(my_rank == 0){
			printf("coucou 2\n");
			MPI_Recv(&nombre_recu,1,MPI_INT,1,tag,MPI_COMM_WORLD,&status);
			nombre_alea += nombre_recu;	
		}else{
			printf("coucou 5\n");
			MPI_Send(&nombre_alea,1,MPI_INT,my_rank-1,tag,MPI_COMM_WORLD);
			//MPI_Recv(nombre_recu,1,MPI_INT,MPI_ANY_SOURCE,tag,MPI_COMM_WORLD,&status);	
		}
	printf("coucou if\n");
	for(i;i<=log(p);i++)
	{
		if ((my_rank>>(i))&1 == 1 && my_rank != 0)
		{
			printf("coucou 3\n");
			if(my_rank < p-(i*2)){
				MPI_Recv(&nombre_recu,1,MPI_INT,my_rank+(i*2),tag,MPI_COMM_WORLD,&status);
				nombre_alea += nombre_recu;
			}
			MPI_Send(&nombre_alea,1,MPI_INT,my_rank-(i*2),tag,MPI_COMM_WORLD);
		}else if((my_rank>>i)&1 == 0){
			printf("coucou 6\n");
			//MPI_Send(&nombre_alea,1,MPI_INT,my_rank-(i*2),tag,MPI_COMM_WORLD);
		}else{
			printf("coucou 4\n");
			MPI_Recv(&nombre_recu,1,MPI_INT,MPI_ANY_SOURCE,tag,MPI_COMM_WORLD,&status);
			nombre_alea += nombre_recu;
		}
	}
	if (my_rank == 0)
	{
		printf("somme = %d\n", nombre_alea);
	}
	MPI_Finalize();
}