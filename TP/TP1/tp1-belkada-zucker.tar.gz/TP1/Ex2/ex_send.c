#include<stdio.h>
#include<string.h>
#include<mpi.h>
#include<unistd.h>

#define SIZE_H_N 50
#define TAILLE 100000

int main(int argc,char argv[])
{
	int	my_rank;
	int	p;	//nombredeprocessus/
	int	source;	//rangdel’emetteur/
	int	dest;	//rangdurecepteur	/
	int	tag=0;	//	etiquettedu	message	/
	int message[TAILLE];
	MPI_Status	status;
	char hostname[SIZE_H_N];

	gethostname(hostname,SIZE_H_N);

//	Initialisation	/
	MPI_Init(&argc,&argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
	MPI_Comm_size(MPI_COMM_WORLD,&p);
	printf("Mon rang est le #%d\n", my_rank);
	// Envoi
	//sprintf(message,"Coucou du processus #%d depuis %s!",my_rank,hostname);
	for (int i = 0; i < TAILLE; ++i)
	{
		message[i] = my_rank;
	}
	if (my_rank < p-1)
	{
		MPI_Send(message, TAILLE, MPI_INT, my_rank+1, tag, MPI_COMM_WORLD);
	}else{
		MPI_Send(message, TAILLE, MPI_INT, 0, tag, MPI_COMM_WORLD);
	}

	// Réception
	if (my_rank == 0)
	{
		MPI_Recv(message,TAILLE,MPI_INT,p-1,tag,MPI_COMM_WORLD,&status);
		printf("Reçu #%d\n", my_rank);
		//printf("Sur %s,le processus #%d a recu le message:%s\n",hostname,my_rank,message);
	}else{
		MPI_Recv(message,TAILLE,MPI_INT,my_rank-1,tag,MPI_COMM_WORLD,&status);
		printf("Reçu #%d\n", my_rank);
		//printf("Sur %s,le processus #%d a recu le message:%s\n",hostname,my_rank,message);
	}

	MPI_Finalize();
}